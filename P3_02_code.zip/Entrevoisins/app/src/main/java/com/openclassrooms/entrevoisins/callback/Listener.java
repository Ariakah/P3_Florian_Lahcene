package com.openclassrooms.entrevoisins.callback;

import com.openclassrooms.entrevoisins.model.Neighbour;

public interface Listener {

        void onItemClick(Neighbour item);

}
